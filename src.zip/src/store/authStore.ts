import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User } from '../types';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (user: User, token: string) => void;
  logout: () => void;
  // Applied when the server tells us (via socket 'role:changed') that an
  // admin changed this person's role — never settable by the user directly.
  applyServerRoleChange: (user: User) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      login: (user, token) => set({ user, token, isAuthenticated: true }),
      logout: () => set({ user: null, token: null, isAuthenticated: false }),
      applyServerRoleChange: (user) => set({ user }),
    }),
    { name: 'fmc-auth' }
  )
);
